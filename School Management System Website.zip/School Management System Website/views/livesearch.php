<?php
include ("../controller/connection.php");

if(isset($_POST['input']))
{
	$input = $_POST['input'];
	$query = "SELECT * FROM information WHERE firstname LIKE '{$input}%' OR lastname LIKE '{$input}%' OR username LIKE '{$input}%' OR email LIKE '{$input}%' OR phone LIKE '{$input}%' OR preaddress LIKE '{$input}%' OR peraddress LIKE '{$input}%'";
	$result = mysqli_query($conn,$query);

	if(mysqli_num_rows($result) > 0)
	{
?>
		<table class="table table-bordered table-striped mt-4" border="1" cellspacing="5" width="100%" style="background-color: yellow">
			<thead>
				<tr>
					<th>ID</th>
					<th>First Name</th>
					<th>Last Name</th>
					<th>Username</th>
					<th>Email Address</th>
					<th>Phone Number</th>
					<th>Present Address</th>
					<th>Permanent Address</th>
				</tr>
			</thead>

			<tbody>
<?php
				while($row = mysqli_fetch_assoc($result))
				{
					$id = $row['id'];
					$firstname = $row['firstname'];
					$lastname = $row['lastname'];
					$username = $row['username'];
					$email = $row['email'];
					$phone = $row['phone'];
					$preaddress = $row['preaddress'];
					$peraddress = $row['peraddress'];
?>
                    <tr>
                    	<td><?php echo $id; ?></td>
                    	<td><?php echo $firstname; ?></td>
                    	<td><?php echo $lastname; ?></td>
                    	<td><?php echo $username; ?></td>
                    	<td><?php echo $email; ?></td>
                    	<td><?php echo $phone; ?></td>
                    	<td><?php echo $preaddress; ?></td>
                    	<td><?php echo $peraddress; ?></td>
                    </tr>
<?php
				}
?>
			</tbody>
		</table>

<?php
	}
	else
	{
		echo "<h6 class='text-danger text-center mt-3'>No data found</h6>";
	}
}
?>