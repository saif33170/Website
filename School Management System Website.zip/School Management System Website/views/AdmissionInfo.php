<?php
include ("../views/Nav.php");
?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="../views/css/AdmissionInfo_Style.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css">
	<title>Contact us</title>
</head>
<body>
	<div class="body">
	<div class="contact-info">
		<div class="card">
			<i class="card-icon fas fa-marker"></i>
			<p>Apply Now</p>
		</div>

		<div class="card">
			<i class="card-icon fas fa-clone"></i>
			<p>Fast Facts</p>
		</div>

		<div class="card">
			<i class="card-icon fas fa-credit-card"></i>
			<p>Fees and Payment</p>
		</div>

		<div class="card">
			<i class="card-icon fas fa-book"></i>
			<p>Scholarships</p>
		</div>

		<div class="card">
			<i class="card-icon fas fa-arrow-right"></i>
			<p>Transfer Procedures</p>
		</div>
	</div>
	</div>
<?php include ("../views/footer.php"); ?>
</body>
</html>