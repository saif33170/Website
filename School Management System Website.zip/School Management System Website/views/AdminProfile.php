<?php
session_start();
include ("../views/NavAll.php");

if(!isset($_SESSION['username']))
{
	$message = "You are logged out! Please login again...";
	echo "<script type='text/javascript'>alert('$message');</script>";
	header('location: ../model/index.php');
}
?>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="../views/css/AdminProfileStyle.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css">
	<title>Admin Profile</title>
</head>
<body>
	<center>
<?php
echo "<h1><b>WELCOME<b> ".$_SESSION['username']."!</h1>";
?>
<div class="body">
	<div class="contact-info">
		<div class="card">
			<i class="card-icon fas fa-chalkboard"></i>
			<p>TEACHERS</p>
		</div>

		<div class="card">
			<i class="card-icon fas fa-user-graduate"></i>
			<p>STUDENTS</p>
		</div>

		<div class="card">
			<i class="card-icon fas fa-stop"></i>
			<p>PROBATION STUDENTS</p>
		</div>

		<div class="card">
			<i class="card-icon fas fa-shapes"></i>
			<p>PENDING APPROVAL</p>
		</div>

		<div class="card">
			<i class="card-icon fas fa-arrow-right"></i>
			<p>TRANSFER CERTIFICATE</p>
		</div>

		<div class="card">
			<i class="card-icon fas fa-file"></i>
			<p>COMPLAINTS</p>
		</div>
	</div>
	</div>
</center>
<?php include ("../views/footer.php"); ?>
</body>
</html>