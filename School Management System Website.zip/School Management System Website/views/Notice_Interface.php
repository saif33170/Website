<?php
session_start();
if(!isset($_SESSION['username']))
{
    $message = "You are logged out! Please login again...";
    echo "<script type='text/javascript'>alert('$message');</script>";
    header('location: ../model/index.php');
}
include ("../views/NavAll.php");
include("../controller/connection.php");
error_reporting(0);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="../views/css/Notice_InterfaceStyle.css">
	<title>Notice</title>
</head>
<body>
		<center>

	<div class="container">
    <form action="#" method="POST">
        <div class="form">
            <div class="title"><h1>GIVE ANNOUNCEMENT</h1></div>
		
        <div class="input_field">
		<label>Date </label>
		<input type="date" class="date" name="date">
		<br><br></div>

		<div class="input_field">
        <label for="notice">Message </label>
		<textarea class="textarea" name="notice" placeholder="Write down your message here..." rows="10" cols="50"></textarea>
		<br><br></div>

		
		
		<input type="submit" value="ANNOUNCE" name="announce" class="notice_btn">
        <button type="reset" class="clear">CLEAR</button>
		<br><br>
        <div class="back">
                  <a href="../model/Notice_Board.php" class="cancel">Back</a>
        </div>
		<br><br>

	</div>
	</form>
    </div>

</center>
<?php include ("../views/footer.php"); ?>
</body>
</html>

<?php
    if ($_POST['announce'])
    {
    	$id         = $_POST['id'];
        $date         = $_POST['date'];
    	$notice      = $_POST['notice'];



    	if($date != "" && $notice != "" )
    	{
    	  $query = "INSERT INTO notice VALUES('$id','$date','$notice')";
    	  $notice_data = mysqli_query($conn,$query);

    	  if($notice_data)
    	  {
    	  	//echo "Notice Published!";
            $_SESSION['success_message'] = "Notice Published!";
            header("Location: ../model/Notice_Board.php");
            exit();
    	  }
    	  else
    	  {
    	  	  echo "Failed to Publish!";
    	  }
        }
        else
        {
        	echo "<script>alert('Please, TRY AGAIN!');</script>";
        }
    }
?>