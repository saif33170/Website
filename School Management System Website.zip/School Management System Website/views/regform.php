<?php
session_start();
if(!isset($_SESSION['username']))
{
	$message = "You are logged out! Please login again...";
	echo "<script type='text/javascript'>alert('$message');</script>";
	header('location: ../model/index.php');
}
?>

<?php
include ("../views/NavAll.php");
include ("../controller/connection.php");
error_reporting(0);
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="../views/css/RegFormStyle.css">
	<title>Add New Member</title>
</head>

<body>
	<div class="container">
		<form action="" method="POST">
		<div class="title">
			NEW MEMBER
		</div>
		<div class="form">
			<div class="input_field">
				<label>First Name</label>
				<input type="text" class="input" autofocus name="fname">
			</div>
			<div class="input_field">
				<label>Last Name</label>
				<input type="text" class="input" name="lname">
			</div>
			<div class="input_field">
				<label>Username</label>
				<input type="text" class="input" name="uname">
			</div>
			<div class="input_field">
				<label>Password</label>
				<input type="password" class="input" name="pass">
			</div>
			<div class="input_field">
				<label>Confirm Password</label>
				<input type="password" class="input" name="conpass">
			</div>
			<div class="input_field">
				<label>Email Address</label>
				<input type="text" class="input" name="email">
			</div>
			<div class="input_field">
				<label>Phone Number</label>
				<input type="text" class="input" name="phone">
			</div>
			<div class="input_field">
				<label>Present Address</label>
				<textarea class="textarea" name="preaddress"></textarea>
			</div>
			<div class="input_field">
				<label>Permanent Address</label>
				<textarea class="textarea" name="peraddress"></textarea>
			</div>
			<div class="input_field">
				<label>Village</label>
				<textarea class="textarea" name="village"></textarea>
			</div>

			<div class="input_field">
				<input type="submit" value="ADD" class="btn" name="register">
			</div>
			<center>
            	<div class="login">
				  <a href="../model/display.php" class="cancel">Back</a>
			    </div>
            </center>
		</div>

	</form>
	</div>
<?php include ("../views/footer.php"); ?>
</body>
</html>

<?php
    if ($_POST['register'])
    {
    	$id         = $_POST['id'];
    	$fname      = $_POST['fname'];
    	$lname      = $_POST['lname'];
    	$uname      = $_POST['uname'];
    	$pass       = $_POST['pass'];
    	$conpass    = $_POST['conpass'];
    	$email      = $_POST['email'];
    	$phone      = $_POST['phone'];
    	$preaddress = $_POST['preaddress'];
    	$peraddress = $_POST['peraddress'];
    	$pvillage = $_POST['village'];


    	if($fname != "" && $lname != "" && $uname != "" && $pass != "" && $conpass != "" && $email != "" && $phone != "" && $preaddress != "" && $peraddress != "" && $village != "" )
    	{
    	  $query = "INSERT INTO information VALUES('$id','$fname','$lname','$uname','$pass','$conpass','$email','$phone','$preaddress','$peraddress','$village')";
    	  $user_data = mysqli_query($conn,$query);

    	  if($user_data)
    	  {
    	  	//echo "You're Registered now!";
            $message = "New Member Added!";
			echo "<script type='text/javascript'>alert('$message');</script>";
?>
            <meta http-equiv = "refresh" content = "1; url = ../model/display.php" />
<?php
    	  }
    	  else
    	  {
    	  	 $message = "Failed to Add New Member!";
			 echo "<script type='text/javascript'>alert('$message');</script>";
    	  }
        }
        else
        {
        	echo "<script>alert('Please, fill the form properly');</script>";
        }
    }
?>