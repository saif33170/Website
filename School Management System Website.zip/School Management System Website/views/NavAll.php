<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="../views/css/NavAllStyle.css">
	<title>Home</title>
</head>
<body>
	<header>
		<nav class="navbar">
			<ul>
				<li><a href="../model/logout.php" onclick='return check_delete()'>Log Out</a></li>
				<li><a href="../views/contact.php">Contact</a></li>
				<li><a href="../views/search.php">Search</a></li>
				<li><a href="../model/Result_Sheet.php">Result</a></li>
				<li><a href="../model/Notice_Board.php">Notice</a></li>
				<li><a href="../model/display.php">Members</a></li>
				<li><a href="../views/AdminProfile.php">Profile</a></li>
				<div class="name">
					<p>ABC HIGH SCHOOL</p>
				</div>
			</ul>
		</nav>
	</header>
	<script>
	  function check_delete()
	  {
		  return confirm('Are you sure, you want to Logout ?');
	  }
    </script>

</body>
</html>