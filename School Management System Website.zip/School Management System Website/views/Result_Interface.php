<?php
session_start();
if(!isset($_SESSION['username']))
{
    $message = "You are logged out! Please login again...";
    echo "<script type='text/javascript'>alert('$message');</script>";
    header('location: ../model/index.php');
}
include ("../views/NavAll.php");
include("../controller/connection.php");
error_reporting(0);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="../views/css/Notice_InterfaceStyle.css">
	<title>Result</title>
</head>
<body>
		<center>

	<div class="container">
    <form action="#" method="POST">
        <div class="form">
            <div class="title"><h1>DISTRIBUTE RESULT</h1></div>
		
        <div class="input_field">
            <label for="stud_name">Student Name</label>
            <input type="text" name="stud_name" id="stud_name" placeholder="Student Name">
            <br><br>
        </div>

        <div class="input_field">
            <label for="marks">Marks</label>
            <input type="text" name="marks" id="marks" placeholder="Marks">
            <br><br>
        </div>

		<div class="input_field">
            <label for="comment">Comment</label>
            <textarea id="comment" name="comment" placeholder="Any comment here..." rows="2" cols="30"></textarea>
            <br><br>
        </div>

		
		
		<input type="submit" value="PUBLISH" name="announce" class="notice_btn">
        <button type="reset" class="clear">CLEAR</button>
		<br><br>
        <div class="back">
                  <a href="../model/Result_Sheet.php" class="cancel">Back</a>
        </div>
		<br><br>

	</div>
	</form>
    </div>

</center>
<?php include ("../views/footer.php"); ?>
</body>
</html>

<?php
    if ($_POST['announce'])
    {
    	$id         = $_POST['id'];
        $stud_name  = $_POST['stud_name'];
    	$marks      = $_POST['marks'];
        $comment    = $_POST['comment'];



    	if($stud_name != "" && $marks != "" )
    	{
    	  $query = "INSERT INTO result VALUES('$id','$stud_name','$marks','$comment')";
    	  $result_data = mysqli_query($conn,$query);

    	  if($result_data)
    	  {
    	  	//echo "Notice Published!";
            $_SESSION['success_message'] = "Result Published!";
            header("Location: ../model/Result_Sheet.php");
            exit();
    	  }
    	  else
    	  {
    	  	  echo "Failed to Publish Result!";
    	  }
        }
        else
        {
        	echo "<script>alert('Please, TRY AGAIN!');</script>";
        }
    }
?>