<?php
include ("../views/Nav.php");
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="../views/css/HomeStyle.css">
	<title>Home</title>
</head>

<body>
	<marquee direction="scroll" class="marquee">
		Welcome to AIUB High School website. ABC High School is an educational institute in Dhaka, Bangladesh.
		It has 4 campuses and around 25,000 students. ABC High School is one of the renowned educational institutes
		in Bangladesh. We consider every child as unique and so we maintain inclusive learning-teaching environment
		at every step in our great set-up.
	</marquee>
	<center>

	<div class="wrapper">
		<div class="bgimg">
			<br><br>
			<img src="../model/img/SchoolLogo.png" height="50" width="500">
			<br><br>
			<img src="../model/img/bgimg.jpg" height="300" width="1100">
		</div>
	</div>
	

	<div class="container">
	<div class="welcome_text">
		<h1>**PRINCIPAL MESSAGE**</h1>
		<p>
			Welcome to ABC High School. ABC High School is an educational institute in Dhaka, Bangladesh.
			It has 4 campuses and around 25,000 students. ABC High School<br> is one of the renowned educational institutes
			in Bangladesh. We consider every child as unique and so we maintain inclusive learning-teaching environment
			at every<br> step in our great set-up. It is a fact now that our results are getting better in the public
			examinations every time. It has been made possible through our extensive and<br> effective care stretched
			out to every individual student. Our students conglomerate here from multifarious backgrounds; various
			strata of the society. They enter the<br> threshold of our strong and fortified home of learning and come
			out bearing an all-round personality.
		</p>
	</div>
	</div>
	</center>
<?php include ("../views/footer.php"); ?>
</body>
</html>