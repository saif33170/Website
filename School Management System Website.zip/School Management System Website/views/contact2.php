<?php
include ("../views/Nav.php");
?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="../views/css/ContactStyle.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css">
	<title>Contact us</title>
</head>
<body>
	<div class="body">
	<div class="contact-info">
		<div class="card">
			<i class="card-icon far fa-envelope"></i>
			<p>email@abc.edu</p>
		</div>

		<div class="card">
			<i class="card-icon fas fa-phone"></i>
			<p>+880 177772345</p>
		</div>

		<div class="card">
			<i class="card-icon fas fa-map-marker-alt"></i>
			<p>Dhaka, Bangladesh</p>
		</div>
	</div>
	</div>
<?php include ("../views/footer.php"); ?>
</body>
</html>