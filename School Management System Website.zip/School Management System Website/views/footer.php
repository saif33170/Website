<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css">
	<link rel="stylesheet" type="text/css" href="../views/css/footer_style.css">
	<title></title>
</head>
<body>
	<footer class="footer">
		<p>&copy Mushfiq Qayyum_17-33170-1 WT[M]__ follow us_
			<a href="#" class="link"><i class="fab fa-facebook-f"></i></a>
		    <a href="#" class="link"><i class="fab fa-twitter"></i></a>
		    <a href="#" class="link"><i class="fab fa-instagram"></i></a>
		    <a href="#" class="link"><i class="fab fa-linkedin-in"></i></a>
		</p>
	</footer>

</body>
</html>