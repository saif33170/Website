<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="../views/css/NavStyle.css">
	<title>Home</title>
</head>
<body>
	<header>
		<nav class="navbar">
			<ul>
				<li><a href="../views/contact2.php">Contact</a></li>
				<li><a href="../views/AdmissionInfo.php">Admission</a></li>
				<li><a href="../model/index.php">Login/Register</a></li>
				<li><a href="../views/Home.php">Home</a></li>
				<div class="name">
					<p>ABC HIGH SCHOOL</p>
				</div>
			</ul>
		</nav>
	</header>

</body>
</html>