<?php
session_start();
if(!isset($_SESSION['username']))
{
	$message = "You are logged out! Please login again...";
	echo "<script type='text/javascript'>alert('$message');</script>";
	header('location: ../model/index.php');
}

include ("../views/NavAll.php");
include ("../controller/connection.php");
?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="../views/css/search_style.css">
	<title>Search</title>
</head>
<body>
	<center>
		<h1>SEARCH MEMBERS</h1>
		<h4>Search members with their<br> First-name, Last-Name, Username, Email, Phone Number, Address</h4>
	<div class="container">

		<input type="text" class="form-control" id="live_search" autocomplete="off" placeholder="Search here...">
		<br><br>
	</div>

	<div id="searchresult"></div>

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

	<script type="text/javascript">
		$(document).ready(function()
		{
			$("#live_search").keyup(function()
				{

					var input = $(this).val();
					//alert(input);
					if (input !="")
					{
						$.ajax(
							{
								url: "../views/livesearch.php",
								method:"POST",
								data:{input:input},

								success:function(data)
								{
									$("#searchresult").html(data);
									$("#searchresult").css("display","block");
								}
							});
					}
					else
					{
						$("#searchresult").css("display","none");
					}
				});
		});
	</script>
	</center>
<?php include ("../views/footer.php"); ?>
</body>
</html>