<?php
session_start();
if(!isset($_SESSION['username']))
{
	$message = "You are logged out! Please login again...";
	echo "<script type='text/javascript'>alert('$message');</script>";
	header('location: ../model/index.php');
}
include ("../views/NavAll.php");
include("../controller/connection.php");
error_reporting(0);

$id     = $_GET['id'];

$query  = "SELECT * FROM information WHERE id = '$id'";
$data   = mysqli_query($conn, $query);

$total  = mysqli_num_rows($data);
$result = mysqli_fetch_assoc($data);
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="../views/css/update_userStyle.css">
	<title>Update</title>
</head>

<body>
	<div class="container">
		<form action="" method="POST">
		<div class="title">
			<b>Update User Information</b>
		</div>
		<div class="form">
			<div class="input_field">
				<label>First Name</label>
				<input type="text" value="<?php echo $result['firstname']; ?>" class="input" autofocus name="firstname">
			</div>
			<div class="input_field">
				<label>Last Name</label>
				<input type="text" value="<?php echo $result['lastname']; ?>" class="input" name="lastname">
			</div>
			<div class="input_field">
				<label>Username</label>
				<input type="text" value="<?php echo $result['username']; ?>" class="input" name="username">
			</div>
			<div class="input_field">
				<label>Password</label>
				<input type="text" value="<?php echo $result['password']; ?>" class="input" name="password">
			</div>
			<div class="input_field">
				<label>Confirm Password</label>
				<input type="text" value="<?php echo $result['conpass']; ?>" class="input" name="conpass">
			</div>
			<div class="input_field">
				<label>Email Address</label>
				<input type="text" value="<?php echo $result['email']; ?>" class="input" name="email">
			</div>
			<div class="input_field">
				<label>Phone Number</label>
				<input type="text" value="<?php echo $result['phone']; ?>" class="input" name="phone">
			</div>
			<div class="input_field">
				<label>Present Address</label>
				<textarea class="textarea" name="preaddress"><?php echo $result['preaddress']; ?></textarea>
			</div>
			<div class="input_field">
				<label>Permanent Address</label>
				<textarea class="textarea" name="peraddress"><?php echo $result['peraddress']; ?></textarea>
			</div>
			<div class="input_field">
				<input type="submit" value="UPDATE" class="btn" name="update">
			</div>

            <center>
            	<div class="login">
				  <a href="../model/display.php" class="cancel">Back</a>
			    </div>
            </center>
			
		</div>
	</form>
	</div>
<?php include ("../views/footer.php"); ?>
</body>
</html>

<?php
    if ($_POST['update'])
    {
    	$firstname  = $_POST['firstname'];
    	$lastname   = $_POST['lastname'];
    	$username   = $_POST['username'];
    	$password   = $_POST['password'];
    	$conpass    = $_POST['conpass'];
    	$email      = $_POST['email'];
    	$phone      = $_POST['phone'];
    	$preaddress = $_POST['preaddress'];
    	$peraddress = $_POST['peraddress'];


    	  $query = "UPDATE information set firstname='$firstname',lastname='$lastname',username='$username',password='$password',conpass='$conpass',email='$email',phone='$phone',preaddress='$preaddress',peraddress='$peraddress' WHERE id='$id'";



    	  $user_data = mysqli_query($conn,$query);

    	  if($user_data)
    	  {
    	  	//echo "Record Updated!";
    	  	$message = "Record Updated!";
			echo "<script type='text/javascript'>alert('$message');</script>";
?>
			<meta http-equiv = "refresh" content = "1; url = ../model/display.php" />
<?php
    	  }
    	  else
    	  {
    	  	//echo "Updating Failed!";
    	  	$message = "Failed to Update!";
			echo "<script type='text/javascript'>alert('$message');</script>";
    	  }
    }
?>