<?php
session_start();
if(!isset($_SESSION['username']))
{
	$message = "You are logged out! Please login again...";
	echo "<script type='text/javascript'>alert('$message');</script>";
	header('location: ../model/index.php');
}
?>

<html>
<head>
	<link rel="stylesheet" type="text/css" href="../views/css/Notice_BoardStyle.css">
	<title>Result Sheet</title>
</head>

<?php
include ("../views/NavAll.php");
include ("../controller/connection.php");
error_reporting(0);

$query  = "SELECT * FROM result";
$data   = mysqli_query($conn,$query);

$total  = mysqli_num_rows($data);
$result = mysqli_fetch_assoc($data);

if($total != 0)
{
	?>

    <h1 align="center">RESULTS</h1>
	<center><table border="1" cellspacing="5" width="37%">
		<tr>
		  <th width="1%">ID</th>
		  <th width="10%">Student Name</th>
		  <th width="5%">Marks</th>
		  <th width="20%">Comment</th>
		  <th width="1%">Action</th>
	    </tr>

	<?php
	while($result = mysqli_fetch_assoc($data))
	{
		echo "<tr>
		       <td>".$result[id]."</td>
		       <td>".$result[stud_name]."</td>
		       <td>".$result[marks]."</td>
		       <td>".$result[comment]."</td>
		       <td><a href='../model/delete_result.php?id=$result[id]'><input type='submit' value='DELETE' class='delete' onclick='return check_delete()'></a></td>
	         </tr>
	         ";
	}
}
else
{
	echo "No records";
}

?>
</table>
<script>
	function check_delete()
	{
		return confirm('Are you sure, you want to Delete the Result ?');
	}
</script>
<br><br>
                <div class="ann">
				  <a href="../views/Result_Interface.php" class="give_ann">Publish</a>
			    </div>
<br><br>
                <div class="login">
				  <a href="../views/AdminProfile.php" class="cancel">Back</a>
			    </div>
</center>
<?php include ("../views/footer.php"); ?>
</html>