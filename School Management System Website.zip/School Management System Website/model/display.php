<?php
session_start();
if(!isset($_SESSION['username']))
{
	$message = "You are logged out! Please login again...";
	echo "<script type='text/javascript'>alert('$message');</script>";
	header('location: ../model/index.php');
}
?>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="../views/css/displayStyle.css">
	<title>Members</title>
</head>

<?php
include ("../views/NavAll.php");
include ("../controller/connection.php");
error_reporting(0);

$query  = "SELECT * FROM information";
$data   = mysqli_query($conn, $query);

$total  = mysqli_num_rows($data);


if($total != 0)
{
	?>

	<h1 align="center">REGISTERED MEMBERS</h1>

	<center><table border="1" cellspacing="5" width="95%">
	  <tr>
		<th width="2%">ID</th>
		<th width="10%">First Name</th>
		<th width="10%">Last Name</th>
		<th width="10%">Username</th>
		<th width="10%">Email ID</th>
		<th width="9%">Phone Number</th>
		<th width="19%">Present Address</th>
		<th width="19%">Permanent Address</th>
		<th width="10%">Action</th>
	  </tr>

	<?php
	while($result = mysqli_fetch_assoc($data))
	{
		echo "<tr>
		       <td>".$result[id]."</td>
		       <td>".$result[firstname]."</td>
		       <td>".$result[lastname]."</td>
		       <td>".$result[username]."</td>
		       <td>".$result[email]."</td>
		       <td>".$result[phone]."</td>
		       <td>".$result[preaddress]."</td>
		       <td>".$result[peraddress]."</td>

		       <td><a href='../model/update_user.php?id=$result[id]'><input type='submit' value='UPDATE' class='update'></a>

		       <a href='../model/delete_user.php?id=$result[id]'><input type='submit' value='REMOVE' class='delete' onclick='return check_delete()'></a></td>
	         </tr>
	         ";
	}
}
else
{
	echo "Table has no record!";
}

?>
</table>
<br><br>
                <div class="add">
                	<a href='../views/regform.php?id=$result[id]'><input type='submit' value='ADD NEW MEMBER' class='add'></a>
                </div><br><br>
                <div class="login">
				  <a href="../views/AdminProfile.php" class="cancel">Back</a>
			    </div>
</center>

<script>
	function check_delete()
	{
		return confirm('Are you sure, you want to Delete the record ?');
	}
</script>
<?php include ("../views/footer.php"); ?>