<?php
session_start();
if(!isset($_SESSION['username']))
{
	$message = "You are logged out! Please login again...";
	echo "<script type='text/javascript'>alert('$message');</script>";
	header('location: ../model/index.php');
}
?>

<html>
<head>
	<link rel="stylesheet" type="text/css" href="../views/css/Notice_BoardStyle.css">
	<title>Notice</title>
</head>

<?php
include ("../views/NavAll.php");
include ("../controller/connection.php");
error_reporting(0);

$query  = "SELECT * FROM notice";
$data   = mysqli_query($conn,$query);

$total  = mysqli_num_rows($data);
$result = mysqli_fetch_assoc($data);

//echo $result[date]." ". $result[notice];
//echo $total;

if($total != 0)
{
	?>

    <h1 align="center">NOTICE BOARD</h1>
	<center><table border="1" cellspacing="5" width="50%">
		<tr>
		  <th width="1%">No</th>
		  <th width="8%">Date</th>
		  <th width="40%">Notice</th>
		  <th width="1%">Action</th>
	    </tr>

	<?php
	while($result = mysqli_fetch_assoc($data))
	{
		echo "<tr>
		       <td>".$result[id]."</td>
		       <td>".$result[date]."</td>
		       <td>".$result[notice]."</td>
		       <td><a href='../model/delete_notice.php?id=$result[id]'><input type='submit' value='DELETE' class='delete' onclick='return check_delete()'></a></td>
	         </tr>
	         ";
	}
}
else
{
	echo "No records";
}

?>
</table>
<script>
	function check_delete()
	{
		return confirm('Are you sure, you want to Delete the Notice ?');
	}
</script>
<br><br>
                <div class="ann">
				  <a href="../views/Notice_Interface.php" class="give_ann">ANNOUNCE</a>
			    </div>
<br><br>
                <div class="login">
				  <a href="../views/AdminProfile.php" class="cancel">Back</a>
			    </div>
</center>
<?php include ("../views/footer.php"); ?>
</html>