<?php
include ("../controller/connection.php");

$id     = $_GET['id'];

$query = "DELETE FROM notice WHERE id='$id'";

$data  = mysqli_query($conn, $query);

if($data)
{
	$message = "Notice Deleted!";
	echo "<script type='text/javascript'>alert('$message');</script>";
?>

<meta http-equiv = "refresh" content = "0; url = ../model/Notice_Board.php" />

<?PHP
}
else
{
	$message = "Failed to Delete!";
	echo "<script type='text/javascript'>alert('$message');</script>";
}
?>