<?php

include ("../views/Nav.php");
error_reporting(0);

	session_start();
	$db = new mysqli("localhost","root","","sign_up");

	if(isset($_POST['submit']))
	{
		$id = $_POST['id'];
		$firstname = $_POST['firstname'];
		$lastname = $_POST['lastname'];
		$username = $_POST['username'];
		$password = $_POST['password'];
		$conpass = $_POST['conpass'];
		$email = $_POST['email'];
		$phone = $_POST['phone'];
		$preaddress = $_POST['preaddress'];
		$peraddress = $_POST['peraddress'];


		if($firstname != "" && $lastname != "" && $username != "" && $password != "" && $conpass != "" && $email != "" && $phone != "" && $preaddress != "" && $peraddress != "" )
	  {
	  	if ($password != $conpass)
	  	{
	  		  $message = "Confirm Password does not match!";
			  echo "<script type='text/javascript'>alert('$message');</script>";
	  	}

	  	else
	  	{
		    $query = "INSERT INTO information(id, firstname, lastname, username, password, conpass, email, phone, preaddress, peraddress) VALUES ('$id' , '$firstname' , '$lastname' , '$username' , '$password', '$conpass' , '$email' , '$phone' , '$preaddress' , '$peraddress')";
		    $run = mysqli_query($db, $query);

		    if($run)
		    {
			$message = "Registration successful!";
			echo "<script type='text/javascript'>alert('$message');</script>";
		    }
		    else
		    {
			echo "error".mysql_error($db);
		    }
	    }
	  }
	  else
      {
        	echo "<script>alert('Please, fill the form properly!');</script>";
      }
	}

	if(isset($_POST['login']))
	{
		$username = $_POST['lusername'];
		$password = $_POST['lpassword'];

		$mysqli = new mysqli("localhost","root","","sign_up");
		$result = $mysqli->query("SELECT * FROM information WHERE username = '$username' AND password ='$password' ");
		$row = $result->fetch_assoc();
		$_SESSION['username'] = $username['username'];

		if($username != "" && $password != "")
		{
		  if($row['username'] == $username && $row['password'] == $password)
		   {
		   	  $_SESSION['username'] = $username;
			  $message = "Login successful!";
			  echo "<script type='text/javascript'>alert('$message');</script>";
?>
			<meta http-equiv = "refresh" content = "1; url = ../views/AdminProfile.php" />
<?php
		   }
		  elseif ($row['username'] != $username && $row['password'] != $password)
		   {
			  $message = "Login unsuccessful!";
			  echo "<script type='text/javascript'>alert('$message');</script>";
		   }
	    }
		else
		   {
			  $message1 = "Login Unsuccessful!";
			  echo "<script type='text/javascript'>alert('$message1');</script>";
		   }
	}

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Login/ Register</title>
	<link rel="stylesheet" type="text/css" href="../views/css/style.css">
</head>
<body>
	<div class="login-page">
		<div id="form" class="form">
			<form action="../model/index.php" method="post" class="register-form">
				<div class="signup"><h1>Register</h1></div>
				<input type="text" name="firstname" placeholder="First Name">
				<input type="text" name="lastname" placeholder="Last Name">
				<input type="text" name="username" placeholder="Username">
				<input type="password" name="password" placeholder="Password">
				<input type="password" name="conpass" placeholder="Confirm Password">
				<input type="text" name="email" placeholder="Email ID">
				<input type="text" name="phone" placeholder="Phone Number">
				<input type="textarea" name="preaddress" placeholder="Present Address">
				<input type="textarea" name="peraddress" placeholder="Permanent Address">
				<button name="submit" class="button">Create</button>
				<p class="message">Already have an account?<a href="#"> Log In</a></p>
			</form>

			<form action="../model/index.php" method="post" class="login-form">
				<div class="signin"><h1>Login</h1></div>
				<input type="text" name="lusername" placeholder="Username">
				<input type="password" name="lpassword" placeholder="Password">
				<button name="login" class="button">Log in</button>
				<p class="message">Not have an account?<a href="#"> Register Here</a></p>
			</form>
		</div>
	</div>

	<script src='http://code.jquery.com/jquery-3.3.1.min.js'></script>
	<script src="../views/js/jquery-3.3.1.min.js"></script>
	<script src="../views/js/popper.min.js"></script>
	<script src="../views/js/bootstarp.min.js"></script>
	<script src="../views/js/custom.js"></script>

	<script>
		$('.message a').click(function(){
			$('form').animate({height: "toggle",opacity: "toggle"}, "slow");
		});
	</script>
	<?php include ("../views/footer.php"); ?>
</body>
</html>